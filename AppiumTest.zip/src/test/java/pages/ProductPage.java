package pages;

import io.appium.java_client.AppiumBy;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ProductPage extends BasePage {

    private final By productsTitleLocator = By.xpath("//android.widget.TextView[contains(@text, 'PRODUCTS')]");
    private final By cartIconLocator = AppiumBy.accessibilityId("test-Cart");
    private final By cartBadgeLocator = By.xpath("//android.view.ViewGroup[@content-desc='test-Cart']/android.view.ViewGroup/android.widget.TextView");
    private final By addToCartButtonLocator = AppiumBy.androidUIAutomator("new UiSelector().textContains(\"ADD TO CART\")");
    private final By removeButtonLocator = AppiumBy.androidUIAutomator("new UiSelector().textContains(\"REMOVE\")");

    public void waitForProductsTitle() {
        wait.until(ExpectedConditions.presenceOfElementLocated(productsTitleLocator));
    }

    public void tapCartIcon() {
        wait.until(ExpectedConditions.elementToBeClickable(cartIconLocator)).click();
    }

    public void tapFirstAddToCartButton() {
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(addToCartButtonLocator)).get(0).click();
    }

    public void tapRemoveButtonByIndex(int index) {
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(removeButtonLocator))
                .get(index).click();
    }

    public void waitForCartBadgeWithCount(int count) {
        wait.until(ExpectedConditions.textToBePresentInElementLocated(cartBadgeLocator, String.valueOf(count)));
    }

    public void waitForCartBadgeToDisappear() {
        wait.until(ExpectedConditions.invisibilityOfElementLocated(cartBadgeLocator));
    }
}