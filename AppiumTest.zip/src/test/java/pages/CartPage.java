package pages;

import io.appium.java_client.AppiumBy;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class CartPage extends BasePage {

    //Locators
    private final By cartTitleLocator = AppiumBy.xpath("//android.widget.TextView[@text='YOUR CART']");
    private final By cartItemLocator = AppiumBy.xpath("//android.view.ViewGroup[@content-desc='test-Item']");

    //Actions
    public void waitForCartTitle() {
        wait.until(ExpectedConditions.presenceOfElementLocated(cartTitleLocator));
    }

    public void waitForCartToBeEmpty() {
        wait.until(driver -> driver.findElements(cartItemLocator).isEmpty());
    }
}