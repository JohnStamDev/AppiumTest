package pages;

import io.appium.java_client.AppiumBy;
import org.openqa.selenium.By;

public class LoginPage extends BasePage {

    private final By usernameFieldLocator = AppiumBy.accessibilityId("test-Username");
    private final By passwordFieldLocator = AppiumBy.accessibilityId("test-Password");
    private final By loginButtonLocator = AppiumBy.accessibilityId("test-LOGIN");
    private final By errorMessageLocator = AppiumBy.accessibilityId("test-Error message");
    private final By menuButtonLocator = AppiumBy.accessibilityId("test-Menu");
    private final By logoutButtonLocator = AppiumBy.accessibilityId("test-LOGOUT");

    public void enterUsername(String username) {
        wait.until(driver -> driver.findElement(usernameFieldLocator)).sendKeys(username);
    }

    public void enterPassword(String password) {
        wait.until(driver -> driver.findElement(passwordFieldLocator)).sendKeys(password);
    }

    public void tapLogin() {
        wait.until(driver -> driver.findElement(loginButtonLocator)).click();
    }

    public void waitForErrorMessage() {
        wait.until(driver -> driver.findElement(errorMessageLocator));
    }

    public void waitForLockedOutMessage() {
        wait.until(driver -> driver.findElement(errorMessageLocator));
    }

    public void openMenu() {
        wait.until(driver -> driver.findElement(menuButtonLocator)).click();
    }

    public void tapLogout() {
        wait.until(driver -> driver.findElement(logoutButtonLocator)).click();
    }

    public void waitForLoginScreen() {
        wait.until(driver -> driver.findElement(loginButtonLocator));
    }
}
