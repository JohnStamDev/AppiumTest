package stepDefinitions;

import io.cucumber.java.en.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import pages.LoginPage;
import pages.ProductPage;

public class LoginSteps {

    private static final Logger logger = LogManager.getLogger(LoginSteps.class);

    private final LoginPage loginPage = new LoginPage();
    private final ProductPage productPage = new ProductPage();

    @Given("the user is on the login screen")
    public void userIsOnLoginScreen() {
        logger.info("User is on the login screen.");
    }

    @When("the user logs in with {string} and {string}")
    public void userLogsInWithCredentials(String username, String password) {
        logger.info("Attempting login with username: '{}' and password: '{}'", username, password);
        loginPage.enterUsername(username);
        loginPage.enterPassword(password);
        loginPage.tapLogin();
    }

    @Then("the user should be redirected to the products page")
    public void verifyUserIsOnProductsPage() {
        logger.info("Verifying that the user is redirected to the Products page.");
        productPage.waitForProductsTitle();
        logger.info("User successfully redirected to the Products page.");
    }

    @Then("an error message should be displayed")
    public void verifyErrorMessageIsDisplayed() {
        logger.info("Verifying that an error message is displayed.");
        loginPage.waitForErrorMessage();
        logger.info("Error message is displayed as expected.");
    }

    @Then("a locked out error message should be displayed")
    public void verifyLockedOutErrorMessage() {
        logger.info("Verifying locked out error message is displayed.");
        loginPage.waitForLockedOutMessage();
        logger.info("Locked out error message displayed correctly.");
    }

    @When("the user opens the menu")
    public void userOpensMenu() {
        logger.info("Opening the app menu.");
        loginPage.openMenu();
    }

    @When("taps the logout button")
    public void userTapsLogout() {
        logger.info("Tapping logout.");
        loginPage.tapLogout();
    }

    @Then("the login screen should be displayed")
    public void verifyLoginScreenIsDisplayed() {
        logger.info("Verifying login screen is displayed after logout.");
        loginPage.waitForLoginScreen();
        logger.info("Login screen is successfully displayed.");
    }
}
