package stepDefinitions;

import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;
import core.BaseTest;
import utils.ReportGenerator;

public class TestHooks {

    BaseTest baseTest = new BaseTest();

    @Before
    public void beforeScenario() {
        try {
            baseTest.setup();
        } catch (Exception e) {
            throw new RuntimeException("Failed to set up Appium driver", e);
        }
    }

    @After
    public void afterScenario() {
        baseTest.tearDown();
    }

    @AfterAll
    public static void afterAllTests() {
        ReportGenerator.generateReport();
    }
}