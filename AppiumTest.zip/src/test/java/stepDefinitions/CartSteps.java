package stepDefinitions;

import io.cucumber.java.en.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import pages.CartPage;
import pages.LoginPage;
import pages.ProductPage;

public class CartSteps {

    private static final Logger logger = LogManager.getLogger(CartSteps.class);

    private final LoginPage loginPage = new LoginPage();
    private final ProductPage productPage = new ProductPage();
    private final CartPage cartPage = new CartPage();

    @Given("the user is logged in with valid credentials")
    public void userIsLoggedInWithValidCredentials() {
        logger.info("Logging in with valid credentials...");
        loginPage.waitForLoginScreen();
        loginPage.enterUsername("standard_user");
        loginPage.enterPassword("secret_sauce");
        loginPage.tapLogin();
        productPage.waitForProductsTitle();
        logger.info("User successfully logged in.");
    }

    @When("the user taps the cart icon")
    public void userTapsCartIcon() {
        logger.info("Tapping the cart icon.");
        productPage.tapCartIcon();
    }

    @Then("the cart page should be displayed")
    public void cartPageShouldBeDisplayed() {
        logger.info("Verifying cart page is displayed.");
        cartPage.waitForCartTitle();
    }

    @When("the user adds a product to the cart")
    public void userAddsProductToCart() {
        logger.info("Adding a product to the cart.");
        productPage.tapFirstAddToCartButton();
    }

    @Then("the cart icon should show 1 item")
    public void cartIconShouldShowOneItem() {
        logger.info("Verifying that the cart icon shows 1 item.");
        productPage.waitForCartBadgeWithCount(1);
    }

    @When("the user removes the product from the cart")
    public void the_user_removes_the_product_from_the_cart() {
        logger.info("Removing product from the cart.");
        productPage.tapRemoveButtonByIndex(0);
    }

    @Then("the cart icon should show no items")
    public void the_cart_icon_should_show_no_items() {
        logger.info("Verifying cart badge is no longer displayed.");
        productPage.waitForCartBadgeToDisappear();
    }

    @Then("the cart page should indicate no items")
    public void cartPageShouldIndicateNoItems() {
        logger.info("Asserting that cart page indicates no items...");
        cartPage.waitForCartToBeEmpty();
    }
}