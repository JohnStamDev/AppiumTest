package core;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;

public class BaseTest {

    protected static AppiumDriver driver;
    String apkPath = System.getProperty("user.home") + "\\apks\\SwagLabs.apk";


    public void setup() {
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        caps.setCapability(MobileCapabilityType.DEVICE_NAME, "emulator-5554");
        caps.setCapability("app", apkPath);
        caps.setCapability("appPackage", "com.swaglabsmobileapp");
        caps.setCapability("appActivity", "com.swaglabsmobileapp.MainActivity");
        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");

        try {
            driver = new AndroidDriver(new URL("http://127.0.0.1:4723/"), caps);
        } catch (MalformedURLException e) {
            throw new RuntimeException("Appium server URL is invalid", e);
        }

        System.out.println("INFO: Appium driver started");
    }

    public void tearDown() {
        if (driver != null) {
            driver.quit();
            System.out.println("INFO: Appium driver stopped");
        }
    }

    public static AndroidDriver getDriver() {
        return (AndroidDriver) driver;
    }

}
