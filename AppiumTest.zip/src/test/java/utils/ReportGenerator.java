package utils;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

import java.io.File;
import java.util.Collections;

public class ReportGenerator {
    public static void generateReport() {
        File reportOutputDirectory = new File("target");
        Configuration config = new Configuration(reportOutputDirectory, "SwagLabs App Tests");

        ReportBuilder reportBuilder = new ReportBuilder(
                Collections.singletonList("target/cucumber.json"), config);

        reportBuilder.generateReports();
    }
}
